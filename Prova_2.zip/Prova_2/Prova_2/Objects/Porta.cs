﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Prova_2.Manager;
using Prova_2.View;

public enum state_door { rot_close, rot_open, stopped}

namespace Prova_2.Objects
{
    class Porta : TModel
    {
        state_door state = state_door.stopped;
        float rotation = 0;

        public Porta(string modelName)
            : base(modelName)
        {
            center = Vector3.Zero;
            world = Matrix.Identity;
            model = SceneManager.staticContent.Load<Model>(@"Models\" + modelName);
        }


        public void RotateX(float angle)
        {
            world = Matrix.Identity;
            world *= Matrix.CreateRotationX(MathHelper.ToRadians(angle));
            world *= Matrix.CreateTranslation(center);
        }

        public override void Update(GameTime gameTime)
        {
            KeyboardState keyState = Keyboard.GetState();

            if (keyState.IsKeyDown(Keys.O))
            {
                state = state_door.rot_open;
            }

            if (keyState.IsKeyDown(Keys.C))
            {
                state = state_door.rot_close;
            }

            switch (state)
            {
                case state_door.rot_close:
                    rotation = MathHelper.Clamp(rotation - gameTime.ElapsedGameTime.Milliseconds * 0.1f, 0, 90);
                    RotateX(rotation);
                    if (rotation == 0)
                    {
                        state = state_door.stopped;
                    }
                    break;

                case state_door.rot_open:
                    rotation = MathHelper.Clamp(rotation + gameTime.ElapsedGameTime.Milliseconds * 0.1f, 0, 90);
                    RotateX(rotation);
                    if (rotation == 90)
                    {
                        state = state_door.stopped;
                    }
                    break;

                case state_door.stopped:
                    //nao sei para que eu criei isso, nem sei pra que usei switch, mas vou mudar nao
                    break;
            }
        }
    }
}
