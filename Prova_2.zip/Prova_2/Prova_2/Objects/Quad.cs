﻿﻿#region using
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Prova_2.Manager;
using Prova_2.View;
#endregion

namespace Prova_2.Objects
{
    enum VERTEX_TYPE { Color, Texture }

    class Quad
    {
        #region private
        protected Matrix world;
        VertexPositionColor[] vertsColor;
        VertexBuffer vertexBuffer;
        BasicEffect basicEffect;
        Effect effect;
        GraphicsDevice device;
        public Vector3 center = Vector3.Zero;
        #endregion

        /// <summary>
        /// Cria um retangulo formado por 2 triangulos. Comecar do ponto inferior esquerdo
        /// e terminar no ponto inferior direito
        /// </summary>
        /// <param name="device">Graphic Device</param>
        /// <param name="p1">ponto inferior esquerdo</param>
        /// <param name="p2">ponto superior esquerdo</param>
        /// <param name="p3">ponto superior direito</param>
        /// <param name="p4">ponto inferior direito</param>
        public Quad(Vector3 p1, Vector3 p2, Vector3 p3, Vector3 p4, Color color = default(Color))
        {
            world = Matrix.Identity;
            device = SceneManager.staticDevice;
            vertsColor = new VertexPositionColor[6];

            if (object.Equals(color, default(Color)))
            {
                vertsColor[0] = new VertexPositionColor(p1, Color.Black);
                vertsColor[1] = new VertexPositionColor(p2, Color.Black);
                vertsColor[2] = new VertexPositionColor(p3, Color.Black);

                vertsColor[3] = new VertexPositionColor(p1, Color.Black);
                vertsColor[4] = new VertexPositionColor(p3, Color.Black);
                vertsColor[5] = new VertexPositionColor(p4, Color.Black);
            }
            else
            {
                vertsColor[0] = new VertexPositionColor(p1, color);
                vertsColor[1] = new VertexPositionColor(p2, color);
                vertsColor[2] = new VertexPositionColor(p3, color);

                vertsColor[3] = new VertexPositionColor(p1, color);
                vertsColor[4] = new VertexPositionColor(p3, color);
                vertsColor[5] = new VertexPositionColor(p4, color);
            }

            vertexBuffer = new VertexBuffer(device, typeof(VertexPositionColor), vertsColor.Length, BufferUsage.None);
            vertexBuffer.SetData<VertexPositionColor>(vertsColor);

            basicEffect = new BasicEffect(device);
        }

        public void Draw(Camera camera)
        {

            device.SetVertexBuffer(this.vertexBuffer);

            basicEffect.World = world;
            basicEffect.View = camera.GetView();
            basicEffect.Projection = camera.GetProjection();
            basicEffect.VertexColorEnabled = true;

            foreach (EffectPass i in this.basicEffect.CurrentTechnique.Passes)
            {
                i.Apply();
                this.device.DrawUserPrimitives<VertexPositionColor>(PrimitiveType.TriangleList, vertsColor, 0, 2);
            }
        }

        public void Translate(Vector3 move)
        {
            world *= Matrix.CreateTranslation(move);
            center += move;
        }

        public void Rotate(Vector3 arround, float angle)
        {
            world *= Matrix.CreateFromAxisAngle(arround, angle);
        }

        public void SetIdentity()
        {
            world = Matrix.Identity;
        }

        public void SetColor(Color color)
        {
            vertsColor[0].Color = color;
            vertsColor[1].Color = color;
            vertsColor[2].Color = color;
            vertsColor[3].Color = color;
            vertsColor[4].Color = color;
            vertsColor[5].Color = color;
        }
    }
}