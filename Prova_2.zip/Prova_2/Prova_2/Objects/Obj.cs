﻿#region using
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Prova_2.View;
using Prova_2.Manager;
#endregion

namespace Prova_2.Objects
{
    class Obj
    {
        #region protected
        protected List<Quad> quads;
        protected Vector3 center;
        #endregion

        //TODO: GABIARRA
        public Obj(String name) 
        {
        }

        public Obj()
        {
            quads = new List<Quad>();
        }

        public Obj(List<Quad> quads)
        {
            this.quads = quads;
        }

        public virtual void Initialize() { }

        public virtual void LoadContent(ContentManager content) { }

        public virtual void Update(GameTime gameTime) { }

        public virtual void Draw(Camera camera)
        {
            foreach (Quad quad in quads)
            {
                quad.Draw(camera);
            }
        }

        public List<Quad> GetQuads()
        {
            return quads;
        }

        public virtual void SetPosition(Vector3 position)
        {
            center = new Vector3(position.X, position.Y, position.Z);
            Translate(center);
        }

        public virtual void SetPosition(float x, float y, float z)
        {
            center = new Vector3(x, y, z);
            Translate(center);
        }

        public Vector3 GetCenter()
        {
            return center;
        }

        /// <summary>
        /// To use only to move on start, not in animations or dinamyc movement
        /// </summary>
        public virtual void Translate(Vector3 move)
        {
            foreach (Quad quad in quads)
            {
                quad.Translate(move);
            }
        }

        /// <summary>
        /// To use only to rotate on start, not in animations or dinamyc rotations
        /// </summary>
        public virtual void Rotate(Vector3 around, float angle)
        {
            foreach (Quad quad in quads)
            {
                quad.Rotate(around, angle);
            }
        }

        public virtual void Move(Vector3 vector)
        {
            center += vector;
        }
    }
}