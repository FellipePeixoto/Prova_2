﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Prova_2.Manager;
using Prova_2.View;


namespace Prova_2.Objects
{
    class TModel : Obj
    {
        protected Model model;
        protected Matrix world;

        public TModel(String modelName)
        {
            center = Vector3.Zero;
            world = Matrix.Identity;
            model = SceneManager.staticContent.Load<Model>(@"Models\" + modelName);
        }

        public override void SetPosition(float x, float y, float z)
        {
            center.X = x;
            center.Y = y;
            center.Z = z;
            world = Matrix.CreateTranslation(x, y, z);
        }

        public override void SetPosition(Vector3 position)
        {
            center = position;
            world *= Matrix.CreateTranslation(position);
        }

        public void SetRotationY(float degrees)
        {
            world *= Matrix.CreateRotationZ(MathHelper.ToRadians(degrees));
        }

        public override void Draw(Camera camera)
        {
            foreach (ModelMesh mesh in model.Meshes)
            {
                foreach (BasicEffect fx in mesh.Effects)
                {
                    fx.EnableDefaultLighting();
                    fx.World = world * mesh.ParentBone.Transform;
                    fx.View = camera.GetView();
                    fx.Projection = camera.GetProjection();
                }
                mesh.Draw();
            }
        }
    }
}