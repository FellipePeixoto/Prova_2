﻿﻿#region using
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Prova_2.Objects;
using Prova_2.View;
#endregion

namespace Prova_2.Manager
{
    static class SceneManager
    {
        #region private
        static List<Scene> scenes;
        static Scene actualScene;
        static Screen screen;
        static Camera actualCamera;
        #endregion

        #region public
        public static ContentManager staticContent;
        public static GraphicsDevice staticDevice;
        public static Effect staticEffect;
        #endregion

        public static void Initialize(GraphicsDevice device, ContentManager content, int screenWidth, int screenHeight)
        {
            staticDevice = device;
            staticContent = content;

            screen = Screen.GetInstance();
            screen.SetWidth(screenWidth);
            screen.SetHeight(screenHeight);

            actualCamera = new CameraFree();
            actualCamera.SetPosition(Vector3.Backward * 15);
        }

        public static void LoadContent(ContentManager content)
        {
            TModel front_wall = new TModel("parede_furada");
            TModel back_wall = new TModel("parede");
            TModel left_wall = new TModel("parede");
            TModel right_wall = new TModel("parede");                        
            TModel front_esq_torre = new TModel("torre");
            TModel front_dir_torre = new TModel("torre");
            TModel front_left_torre = new TModel("torre");
            TModel back_dir_torre = new TModel("torre");
            TModel back_left_torre = new TModel("torre");
            TModel torre_central = new TModel("quasela");
            Porta door = new Porta("porta");
            Grid chao = new Grid("bump","bump");
            Ocean ocean = new Ocean("ocean");
            Flag flag = new Flag("bandeira");

            torre_central.SetPosition(Vector3.Up * 7);
            torre_central.SetPosition(Vector3.Forward * 0.7f);

            flag.SetPosition(Vector3.Forward *9.5f);
            flag.SetPosition(Vector3.Down * 7);
            flag.RotateX(90);

            ocean.SetPosition(Vector3.Down * 4.2f);
            ocean.SetPosition(Vector3.Forward * 10f);

            chao.SetScale(0.1f);
            chao.SetPosition(Vector3.Forward * 12);
            chao.SetPosition(Vector3.Down * 6.7f);

            left_wall.SetRotationY(90);
            left_wall.SetPosition(Vector3.Left * 7 + Vector3.Up * 7);
            right_wall.SetRotationY(90);
            right_wall.SetPosition(Vector3.Right * 7 + Vector3.Up * 7);
            back_wall.SetPosition(Vector3.Up * 14);
            door.SetPosition(Vector3.Down * 1.3f + Vector3.Forward * 4.143f);

            front_esq_torre.SetPosition(Vector3.Left * 7);
            front_dir_torre.SetPosition(Vector3.Right * 7);
            back_left_torre.SetPosition(Vector3.Left * 7 + Vector3.Up * 14);
            back_dir_torre.SetPosition(Vector3.Right * 7 + Vector3.Up * 14);

            //TODO: Create sets
            //TODO: Include objects on set
            List<Obj> sceneSet = new List<Obj>
            {
                front_wall,
                left_wall,
                right_wall,
                back_wall,
                front_esq_torre,
                front_dir_torre,
                back_dir_torre,
                back_left_torre,
                door,
                chao,
                ocean,
                torre_central,
                flag
            };

            //TODO: Create scenes
            //TODO: Insert the set of objects on scene
            actualScene = new Scene(sceneSet, "Cena 1");

            //TODO: add the scences
            scenes = new List<Scene>();
            scenes.Add(actualScene);
        }

        public static void Update(GameTime gameTime)
        {
            //TODO: Logic to update a scene
            actualCamera.Update(gameTime);
            actualScene.Update(gameTime);
        }

        public static void Draw()
        {
            //TODO: Logic to draw a scene
            actualScene.Draw(actualCamera);
        }

        public static Scene GetActualScene()
        {
            return actualScene;
        }
    }
}
